ems
===

设备管理系统

可以执行 `docker  build -t ems .`自行构建镜像 

或者运行命令`docker run -d --name ems -p 8000:8000 xiaomao361/ems `
