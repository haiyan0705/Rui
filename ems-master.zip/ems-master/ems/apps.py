from django.apps import AppConfig


class EmsConfig(AppConfig):
    name = 'ems'
